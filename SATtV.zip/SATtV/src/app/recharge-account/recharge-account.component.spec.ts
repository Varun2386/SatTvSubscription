import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {HttpClient} from '@angular/common/http';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {RechargeAccountComponent} from './recharge-account.component';
import {GetAccountBalance} from '../account-balance/services/get-account-balance.service';

fdescribe('RechargeAccountComponent', () => {
  let component: RechargeAccountComponent;
  let fixture: ComponentFixture<RechargeAccountComponent>;
  let mockAccountBalanceService: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RechargeAccountComponent],
      providers: [{provide: mockAccountBalanceService, useClass: GetAccountBalance}],
      schemas: [NO_ERRORS_SCHEMA],
      imports: [RouterTestingModule, HttpClientTestingModule],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RechargeAccountComponent);
    component = fixture.componentInstance;
    mockAccountBalanceService = fixture.debugElement.injector.get(GetAccountBalance);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  describe('rechargeAccount test', () => {
    it('should test rechargeAccount function', () => {
      sessionStorage.setItem('amount', '500');
      const data = {
        id: 1,
        name: 'Product001',
        accountBalance: 561
      };
      spyOn(mockAccountBalanceService, 'patchAccountBalance').and.callThrough();
      component.rechargeAccount('550');
      expect(mockAccountBalanceService.patchAccountBalance).toHaveBeenCalled();
      expect(component.accountRecharged).toBe(true);
    });
  });
});
