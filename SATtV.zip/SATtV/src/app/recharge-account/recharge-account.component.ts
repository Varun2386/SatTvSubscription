import {ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {GetAccountBalance} from '../account-balance/services/get-account-balance.service';

@Component({
  selector: 'recharge-acct',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './recharge-account.component.html',
  styleUrls: ['./recharge-account.component.less']
})
export class RechargeAccountComponent implements OnInit {

  constructor(private getAccountBalanceService: GetAccountBalance, private changeDetectorRef: ChangeDetectorRef) {
  }

  rechargedAmount;
  accountRecharged = false;

  ngOnInit() {
  }

  rechargeAccount(value) {
    // tslint:disable-next-line:no-conditional-assignment
    if (value !== '') {
      const previousAmount = Number(sessionStorage.getItem('amount'));
      this.accountRecharged = true;
      this.rechargedAmount = previousAmount + Number(value);
      this.getAccountBalanceService.patchAccountBalance(Number(value) + previousAmount, 1).subscribe(
        (data: any) => {
          this.changeDetectorRef.detectChanges();
          sessionStorage.setItem('amount', data.accountBalance);
        },
        error => {
          console.log(error);
        });
    }
  }

}
