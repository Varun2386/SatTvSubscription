import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AccountBalanceComponent} from "./account-balance/account-balance.component";
import {RechargeAccountComponent} from "./recharge-account/recharge-account.component";
import {PackageComponent} from "./packages/package.component";
import {UpdateContactDetailsComponent} from "./update-contact-details/update-contact-details.component";


const routes: Routes = [
  { path: 'account-balance', component: AccountBalanceComponent },
  { path: 'recharge', component: RechargeAccountComponent },
  { path: 'package', component: PackageComponent },
  { path: 'update-contact-details' , component: UpdateContactDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
