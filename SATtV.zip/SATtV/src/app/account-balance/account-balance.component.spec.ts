import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {AccountBalanceComponent} from './account-balance.component';
import {GetAccountBalance} from './services/get-account-balance.service';
import {HttpClient} from '@angular/common/http';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';

fdescribe('AccountBalanceComponent', () => {
  let component: AccountBalanceComponent;
  let fixture: ComponentFixture<AccountBalanceComponent>;
  let mockAccountBalanceService: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AccountBalanceComponent],
      providers: [{provide: mockAccountBalanceService, useClass: GetAccountBalance}],
      schemas: [NO_ERRORS_SCHEMA],
      imports: [RouterTestingModule, HttpClientTestingModule],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountBalanceComponent);
    component = fixture.componentInstance;
    mockAccountBalanceService = fixture.debugElement.injector.get(GetAccountBalance);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  describe('ngOnInIt test', () => {
    it('should test ngOnInit function', () => {
      const data = {
        id: 1,
        name: 'Product001',
        accountBalance: 561
      };
      spyOn(mockAccountBalanceService, 'getAccountDetails').and.callThrough();
      component.ngOnInit();
      expect(mockAccountBalanceService.getAccountDetails).toHaveBeenCalled();
    });
  });
});
