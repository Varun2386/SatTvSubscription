import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class GetAccountBalance {

  constructor(private httpClient: HttpClient) {
  }

  baseUrl = 'http://localhost:3000';

  getAccountDetails() {
    return this.httpClient.get(this.baseUrl + '/accountDetails');
  }

  patchAccountBalance(amount: number, id) {
    return this.httpClient.patch(this.baseUrl + '/accountDetails/' + id, {
      id,
      name: 'Product001', accountBalance: amount
    });
  }

  getPackageDetails() {
    return this.httpClient.get(this.baseUrl + '/packageDetails/');
  }

  getContactDetails() {
    return this.httpClient.get(this.baseUrl + '/contactDetails/');
  }

  getExtraPackages() {
    return this.httpClient.get(this.baseUrl + '/extraPackages/');
  }

  updateContactDetails(email, phnNumber, id) {
    return this.httpClient.patch(this.baseUrl + '/contactDetails/' + id, {
      id,
      name: 'Product001',
      email: email ,
      phnNumber: phnNumber,
    });
  }

  getSubscriptionDetails() {
    return this.httpClient.get(this.baseUrl + '/subscriptionDuration/');

  }
}
