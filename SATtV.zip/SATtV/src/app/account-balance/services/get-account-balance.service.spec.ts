import {TestBed} from '@angular/core/testing';
import {GetAccountBalance} from './get-account-balance.service';
import {HttpClient} from '@angular/common/http';

let httpClient : HttpClient;
let service: any;

fdescribe('GetAccountBalance', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('GetAccountBalance service should be created', () => {
    service = new GetAccountBalance(httpClient);
    expect(service).toBeTruthy();
  });
  // it('should test getAccountDetails function', () => {
  //   const data: any = {
  //     id: 1,
  //     name: 'Product001',
  //     accountBalance: 561
  //   };
  //   spyOn(httpClient, 'get').and.callThrough();
  //   service.getAccountDetails();
  //   expect(httpClient.get).toHaveBeenCalled();
  // });
});
