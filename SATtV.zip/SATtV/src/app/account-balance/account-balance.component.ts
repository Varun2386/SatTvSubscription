import {Component, OnInit} from '@angular/core';
import {GetAccountBalance} from "./services/get-account-balance.service";
import {Observable} from 'rxjs/Observable';

@Component({
  selector: 'app-home',
  templateUrl: './account-balance.component.html',
  styleUrls: ['./account-balance.component.less']
})
export class AccountBalanceComponent implements OnInit {

  constructor(private getAccountBalanceService: GetAccountBalance) {
  }

  accountBalance: any;

  ngOnInit() {
    this.getAccountBalanceService.getAccountDetails().subscribe(
      data => {
        this.accountBalance = data[0].accountBalance;
        sessionStorage.setItem('amount' , this.accountBalance);
      },
      err => {
        console.log(err);
      }
    );
  }
}
