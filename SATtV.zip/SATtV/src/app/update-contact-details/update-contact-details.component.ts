import {Component, OnInit} from '@angular/core';
import {GetAccountBalance} from '../account-balance/services/get-account-balance.service';
import {SuccessDialogComponent} from '../success-dialog/success-dialog.component';
import {MatDialog} from '@angular/material/dialog';

@Component({
  selector: 'app-update-contact-details',
  templateUrl: './update-contact-details.component.html',
  styleUrls: ['./update-contact-details.component.less']
})
export class UpdateContactDetailsComponent implements OnInit {
  contactDetails$: Object;
  emailValue;
  phnNumberValue;
  constructor(private updateContact: GetAccountBalance, private matDialog: MatDialog) {
  }

  ngOnInit() {
    this.updateContact.getContactDetails().subscribe(
      data => {
        this.contactDetails$ = data;
        this.emailValue = data[0].email;
        this.phnNumberValue = data[0].phnNumber;
      }
    );
  }

  updateContactDetails(email, phnNumber, id) {
    id = 1;
    this.updateContact.updateContactDetails(email, phnNumber, id).subscribe();
    const successMessage = 'You have successfully updated your Contact Details';
    this.matDialog.open(SuccessDialogComponent, {
      width: '500px',
      data: {message: successMessage},
      disableClose: true,
    });
  }
}
