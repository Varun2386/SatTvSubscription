import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {UpdateContactDetailsComponent} from './update-contact-details.component';
import {GetAccountBalance} from '../account-balance/services/get-account-balance.service';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {MatDialog, MatDialogModule} from '@angular/material/dialog';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {SuccessDialogComponent} from '../success-dialog/success-dialog.component';

fdescribe('UpdateContactDetailsComponent', () => {
  let component: UpdateContactDetailsComponent;
  let fixture: ComponentFixture<UpdateContactDetailsComponent>;
  let mockAccountBalanceService: any;
  let matDialog: any;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [UpdateContactDetailsComponent, SuccessDialogComponent],
      providers: [{provide: mockAccountBalanceService, useClass: GetAccountBalance},
        {provide: matDialog, useClass: MatDialog}],
      schemas: [NO_ERRORS_SCHEMA],
      imports: [RouterTestingModule, HttpClientTestingModule, MatDialogModule, BrowserAnimationsModule],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateContactDetailsComponent);
    component = fixture.componentInstance;
    mockAccountBalanceService = fixture.debugElement.injector.get(GetAccountBalance);
    matDialog = fixture.debugElement.injector.get(MatDialog);

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  describe('updateContactDetails test', () => {
    it('should test updateContactDetails function', () => {
      const data = {
        contactDetails: [
          {
            id: 1,
            email: '',
            phnNumber: '7507004545',
            name: 'Product001'
          }
        ]
      };
      spyOn(mockAccountBalanceService, 'updateContactDetails').and.callThrough();
      spyOn(matDialog, 'open');
      component.updateContactDetails('test@werty.com', 7020318041, 1);
      expect(mockAccountBalanceService.updateContactDetails).toHaveBeenCalledWith('test@werty.com', 7020318041, 1);
      expect(mockAccountBalanceService.updateContactDetails).toHaveBeenCalled();
      expect(matDialog.open).toHaveBeenCalled();
    });
  });
});
