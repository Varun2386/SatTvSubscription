// import {TestBed, async} from '@angular/core/testing';
// import {RouterTestingModule} from '@angular/router/testing';
// import {AppComponent} from './app.component';
// import {AppRoutingModule} from './app-routing.module';
// import {HttpClientModule} from '@angular/common/http';
// import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
// import {MatToolbarModule} from '@angular/material/toolbar';
// import {MatIconModule} from '@angular/material/icon';
// import {MatButtonModule} from '@angular/material/button';
// import {MatCardModule} from '@angular/material/card';
// import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
// import {MatFormFieldModule} from '@angular/material/form-field';
// import {MatInputModule} from '@angular/material/input';
// import {MatSelectModule} from '@angular/material/select';
// import {MatDialogModule} from '@angular/material/dialog';
// import {AccountBalanceComponent} from './account-balance/account-balance.component';
// import {RechargeAccountComponent} from './recharge-account/recharge-account.component';
// import {UpdateContactDetailsComponent} from './update-contact-details/update-contact-details.component';
// import {PackageComponent} from './packages/package.component';
// import {NO_ERRORS_SCHEMA} from '@angular/core';
// import {APP_BASE_HREF} from '@angular/common';
//
// xdescribe('AppComponent', () => {
//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       imports: [
//         RouterTestingModule,
//         AppRoutingModule,
//         HttpClientModule,
//         BrowserAnimationsModule,
//         MatToolbarModule,
//         MatIconModule,
//         MatButtonModule,
//         MatCardModule,
//         MatProgressSpinnerModule,
//         MatFormFieldModule,
//         MatInputModule,
//         MatSelectModule,
//         MatDialogModule,
//       ],
//       schemas: [NO_ERRORS_SCHEMA],
//       declarations: [
//         AppComponent, AccountBalanceComponent, RechargeAccountComponent, UpdateContactDetailsComponent, PackageComponent
//       ],
//     }).compileComponents();
//   }));
//
//   it('should create the app', () => {
//     const fixture = TestBed.createComponent(AppComponent);
//     const app = fixture.debugElement.componentInstance;
//     expect(app).toBeTruthy();
//   });
//
//   it(`should have as title 'angular-example'`, () => {
//     const fixture = TestBed.createComponent(AppComponent);
//     const app = fixture.debugElement.componentInstance;
//     expect(app.title).toEqual('angular-example');
//   });
//
//   it('should render title', () => {
//     const fixture = TestBed.createComponent(AppComponent);
//     fixture.detectChanges();
//     const compiled = fixture.debugElement.nativeElement;
//     expect(compiled.querySelector('.content span').textContent).toContain('angular-example app is running!');
//   });
// });
