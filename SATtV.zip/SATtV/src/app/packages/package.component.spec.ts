import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {GetAccountBalance} from '../account-balance/services/get-account-balance.service';
import {PackageComponent} from './package.component';
import {MatDialog, MatDialogModule} from '@angular/material/dialog';
import {Router} from '@angular/router';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {SuccessDialogComponent} from '../success-dialog/success-dialog.component';

fdescribe('PackageComponent', () => {
  const mockRouter = {
    navigate: jasmine.createSpy('navigate')
  };
  let component: PackageComponent;
  let fixture: ComponentFixture<PackageComponent>;
  let mockAccountBalanceService: any;
  let matDialog: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PackageComponent, SuccessDialogComponent],
      providers: [{provide: mockAccountBalanceService, useClass: GetAccountBalance},
        {provide: matDialog, useClass: MatDialog},
        {provide: Router, useValue: mockRouter}],
      schemas: [NO_ERRORS_SCHEMA],
      imports: [RouterTestingModule, HttpClientTestingModule, MatDialogModule, BrowserAnimationsModule],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PackageComponent);
    component = fixture.componentInstance;
    mockAccountBalanceService = fixture.debugElement.injector.get(GetAccountBalance);
    matDialog = fixture.debugElement.injector.get(MatDialog);
    fixture.detectChanges();
    spyOn(matDialog, 'open');
  });

  it('should create component instance', () => {
    expect(component).toBeTruthy();
  });
  describe('PackageComponent test', () => {
    it('should test ngOInIt function', () => {
      sessionStorage.setItem('amount', '500');
      const data = {
        id: 1,
        name: 'Product001',
        accountBalance: 561
      };
      spyOn(mockAccountBalanceService, 'getSubscriptionDetails').and.callThrough();

      spyOn(mockAccountBalanceService, 'getPackageDetails').and.callThrough();
      spyOn(mockAccountBalanceService, 'getExtraPackages').and.callThrough();

      component.ngOnInit();
      expect(mockAccountBalanceService.getPackageDetails).toHaveBeenCalled();
      expect(mockAccountBalanceService.getExtraPackages).toHaveBeenCalled();
      expect(mockAccountBalanceService.getSubscriptionDetails).toHaveBeenCalled();
      expect(component.hasAmount).toBe(false);
    });
  });

  describe('to test setPackage function', () => {
    it('should test setPackage function to set isGoldSelected to true', () => {
      const event = {
        value: 'Gold'
      };
      component.setPackage(event);
      expect(component.isGoldSelected).toBe(true);
    });
    it('should test setPackage function to set isGoldSelected to false', () => {
      const event = {
        value: 'Silver'
      };
      component.setPackage(event);
      expect(component.isGoldSelected).toBe(false);
    });
  });
  describe('should test selectedExtraPackage function', () => {
    it('should test selectedExtraPackage to set LearnCooking to true', () => {
      const extraPackage = {
        value: 'Learn Cooking'
      };
      component.selectedExtraPackage(extraPackage);
      expect(component.LearnCooking).toBe(true);
    });
    it('should test selectedExtraPackage to set LearnCooking to false', () => {
      const extraPackage = {
        value: 'Learn English'
      };
      component.selectedExtraPackage(extraPackage);
      expect(component.LearnCooking).toBe(false);
    });
  });
  describe('should test selectedPackage function', () => {
    sessionStorage.setItem('amount', String(500));
    it('should test selectedPackage if only gold package is selected', () => {
      spyOn(mockAccountBalanceService, 'patchAccountBalance').and.callThrough();
      component.isGoldSelected = true;
      component.selectedPackage();
      expect(mockAccountBalanceService.patchAccountBalance).toHaveBeenCalled();
    });
    it('should test selectedPackage if  gold package and learn cooking is selected', () => {
      spyOn(mockAccountBalanceService, 'patchAccountBalance').and.callThrough();
      component.isGoldSelected = true;
      component.LearnCooking = true;
      component.selectedPackage();
      expect(mockAccountBalanceService.patchAccountBalance).toHaveBeenCalled();
    });
    it('should test selectedPackage if  gold package is selected and learn cooking is not selected', () => {
      spyOn(mockAccountBalanceService, 'patchAccountBalance').and.callThrough();
      component.isGoldSelected = true;
      component.LearnCooking = false;
      component.selectedPackage();
      expect(mockAccountBalanceService.patchAccountBalance).toHaveBeenCalled();
    });
    it('should test selectedPackage if  silver package is selected and learn cooking is not selected', () => {
      spyOn(mockAccountBalanceService, 'patchAccountBalance').and.callThrough();
      component.isGoldSelected = false;
      component.LearnCooking = false;
      component.selectedPackage();
      expect(mockAccountBalanceService.patchAccountBalance).toHaveBeenCalled();
    });
    it('should test selectedPackage if  silver package is selected and learn cooking is selected', () => {
      spyOn(mockAccountBalanceService, 'patchAccountBalance').and.callThrough();
      component.isGoldSelected = false;
      component.LearnCooking = true;
      component.selectedPackage();
      expect(mockAccountBalanceService.patchAccountBalance).toHaveBeenCalled();
    });
  });
  describe('subscriptionSelected tests', () => {
    it('should test subscriptionSelected function if discpount is applicable', () => {
      spyOn(mockAccountBalanceService, 'patchAccountBalance').and.callThrough();
      component.discountApplicable = true;
      component.subscriptionSelected(1000, 100);
      expect(mockAccountBalanceService.patchAccountBalance).toHaveBeenCalled();
    });
    it('should test subscriptionSelected function if discpount is not applicable', () => {
      spyOn(mockAccountBalanceService, 'patchAccountBalance').and.callThrough();
      component.discountApplicable = false;
      component.subscriptionSelected(1000, 100);
      expect(mockAccountBalanceService.patchAccountBalance).toHaveBeenCalled();
    });
  });
  describe('navigateToRecharge tests', () => {
    it('should test navigateToRecharge function', () => {
      component.navigateToRecharge();
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/recharge']);
    })
  })
});
