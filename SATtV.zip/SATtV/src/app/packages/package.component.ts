import {Component, OnInit} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {GetAccountBalance} from '../account-balance/services/get-account-balance.service';
import {MatAutocompleteSelectedEvent} from '@angular/material';
import {Router} from '@angular/router';
import {MatDialog} from '@angular/material/dialog';
import {SuccessDialogComponent} from '../success-dialog/success-dialog.component';

export interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'package',
  templateUrl: './package.component.html',
  styleUrls: ['./package.component.less'],
})
export class PackageComponent implements OnInit {

  constructor(private packageDetails: GetAccountBalance, private router: Router,
              private matDialog: MatDialog) {
  }

  // tslint:disable-next-line:ban-types
  packageDetails$: Object;
  subscriptionDuration$: Object;
  accountBalance: any;
  isGoldSelected;
  isHidden = false;
  extraPackages$: Object;
  enableSubmit = false;
  LearnCooking;
  extraPackageText;
  successMessage;
  hasAmount;
  discountApplicable;
  durationtext;
  goldChannels;
  silverChannels;
  previousAmount = Number(sessionStorage.getItem('amount'));


  ngOnInit() {
    this.previousAmount >= 800 ? this.hasAmount = true : this.hasAmount = false;
    this.packageDetails.getPackageDetails().subscribe(
      data => {
        this.packageDetails$ = data;
        this.goldChannels = data[0].channels;
        this.silverChannels = data[1].channels;
      },
      error => {
        console.log(error);
      });
    this.packageDetails.getSubscriptionDetails().subscribe(
      data => {
        this.subscriptionDuration$ = data;
      },
      error => {
        console.log(error);
      });
    this.packageDetails.getExtraPackages().subscribe(
      data => {
        this.extraPackages$ = data;
      },
      error => {
        console.log(error);
      }
    );
  }

  setPackage(event: any) {
    event.value === 'Gold' ? this.isGoldSelected = true : this.isGoldSelected = false;
    this.isHidden = true;
  }

  subscriptionDuration(durationSelected) {
    this.durationtext = true;
    this.enableSubmit = true;
    durationSelected.value === '3 Months' ? this.discountApplicable = true : this.discountApplicable = false;
  }

  selectedExtraPackage(extraPackage) {
    this.extraPackageText = true;
    extraPackage.value === 'Learn Cooking' ? this.LearnCooking = true : this.LearnCooking = false;

  }

  selectedPackage() {
    const goldPackageAmount = 100;
    const silverPackageAmount = 50;
    const previousAmount = Number(sessionStorage.getItem('amount'));

    if (this.isGoldSelected) {
      if (this.LearnCooking && previousAmount > (goldPackageAmount + goldPackageAmount)) {
        const learnCookingAmount = 100;
        const amountToDeduct = goldPackageAmount + learnCookingAmount;
        this.subscriptionSelected(previousAmount, amountToDeduct);
      } else if (!this.LearnCooking && previousAmount > (goldPackageAmount + silverPackageAmount)) {
        const amountToDeduct = goldPackageAmount + silverPackageAmount;
        this.subscriptionSelected(previousAmount, amountToDeduct);
      } else if (previousAmount > goldPackageAmount) {
        const amountToDeduct = goldPackageAmount;
        this.subscriptionSelected(previousAmount, amountToDeduct);
      }
    } else if (!this.isGoldSelected) {
      if (this.LearnCooking && previousAmount > (silverPackageAmount + goldPackageAmount)) {
        const learnCookingAmount = 100;
        const amonutToDeduct = silverPackageAmount + learnCookingAmount;
        this.subscriptionSelected(previousAmount, amonutToDeduct);
      } else if (!this.LearnCooking && previousAmount > (silverPackageAmount + silverPackageAmount)) {
        const amountToDeduct = silverPackageAmount + silverPackageAmount;
        this.subscriptionSelected(previousAmount, amountToDeduct);
      } else if (previousAmount > silverPackageAmount) {
        this.subscriptionSelected(previousAmount, silverPackageAmount);
      }
    }
    this.successMessage = 'You have successfully subscribed to a package';
    this.openDialog();
  }

  openDialog() {
    const dialogRef = this.matDialog.open(SuccessDialogComponent, {
      width: '500px',
      height: '250px',
      data: {message: this.successMessage},
      disableClose: true,
      panelClass: 'custom-modalbox',
    });
  }

  navigateToRecharge() {
    this.router.navigate(['/recharge']);
  }

  subscriptionSelected(previousAmount: number, amountToDeduct: number) {
    const subscriptionAdded = amountToDeduct * 3;
    const subscriptionAddedDisct = subscriptionAdded - (subscriptionAdded * (10 / 100));
    if (this.discountApplicable && previousAmount > subscriptionAddedDisct) {
      this.packageDetails.patchAccountBalance(previousAmount - subscriptionAddedDisct, 1).subscribe();
    } else {
      this.packageDetails.patchAccountBalance(previousAmount - amountToDeduct, 1).subscribe();
    }
  }

}
